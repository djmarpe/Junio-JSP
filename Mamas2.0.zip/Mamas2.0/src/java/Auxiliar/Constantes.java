/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Auxiliar;

/**
 *
 * @author fernando
 */
public class Constantes {
    public static String BBDD="mamas2.0";
    public static String usuario="alejandro";
    public static String password="Chubaca2020";
}
